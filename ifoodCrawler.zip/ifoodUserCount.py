import requests
import time
import json
start = time.time()
with open('/Workspace/data/userlist.json','r') as f:
    old = json.load(f)
head = {
    'User-Agent': 'ai shi ji/5.2.0 (iPhone; iOS 9.3.1; Scale/2.00)User-Agent: ai shi ji/5.2.0 (iPhone; iOS 9.3.1; Scale/2.00)'
}
url = 'https://ifoodie.tw/api/user/?limit={}&offset={}'
userSet = set(old['users'])
limit = 300
offset = 0
user = {}
count = 1
while True:
    try:
        res = requests.get(url.format(limit, offset), headers=head)
        jd = json.loads(res.text, encoding='utf8')
        r = jd['response']
        for u in jd['response']:
            userSet.add(u['id'])
            userList = list(userSet)
            user['users'] = userList
            print '%d /' % count,'%d users' % len(userList)
            count += 1
    except:
        "no response"
    if len(r) < 300:
        break
    offset += limit
with open('/Workspace/data/userlist.json','w') as f:
    json.dump(user,f)
print time.time()-start
